/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ims.pendenzen;

/**
 * GUI builder created Form
 *
 * @author ricky
 */
public class ToDosForm extends com.codename1.ui.Form {

    public ToDosForm() {
        this(com.codename1.ui.util.Resources.getGlobalResources());
    }
    
    public ToDosForm(com.codename1.ui.util.Resources resourceObjectInstance) {
        
        initGuiBuilderComponents(resourceObjectInstance);
    }

//-- DON'T EDIT BELOW THIS LINE!!!


// <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initGuiBuilderComponents(com.codename1.ui.util.Resources resourceObjectInstance) {
        setLayout(new com.codename1.ui.layouts.LayeredLayout());
        setInlineStylesTheme(resourceObjectInstance);
                setInlineStylesTheme(resourceObjectInstance);
        setTitle("ToDosForm");
        setName("ToDosForm");
    }// </editor-fold>

//-- DON'T EDIT ABOVE THIS LINE!!!
}
